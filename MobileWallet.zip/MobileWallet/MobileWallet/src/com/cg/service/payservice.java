package com.cg.service;

import com.cg.bean.Account;
import com.cg.bean.Customer;

public interface payservice {

	
	public int createAccount(Customer cust,Account acc);
	public int show_balance(int accno);
	public int updateBalance(int accno,int bal);
	public int withdraw(int accno,int bal);
	public int fundTransfer(int myacc,int depacc,int bal);
	public void Print_Transaction(int amt);
}
