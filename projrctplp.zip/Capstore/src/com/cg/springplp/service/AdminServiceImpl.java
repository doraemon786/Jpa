package com.cg.springplp.service;

public class AdminServiceImpl {

}
