package com.cg.springplp.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.validator.constraints.NotBlank;

@Entity
public class Transaction 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="trans_id")
	private int transactionId;
	//@NotBlank(message="This field can't be empty")
	@OneToOne (cascade=CascadeType.ALL)
	private CustomerOrder order;

	private ModeOfPayment paymentMethod;
	
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public CustomerOrder getOrder() {
		return order;
	}
	public void setOrder(CustomerOrder order) {
		this.order = order;
	}
	public ModeOfPayment getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(ModeOfPayment paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	
	/*@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", order=" + order + ", paymentMethod=" + paymentMethod
				+ "]";
	}
	
	*/
	
}
