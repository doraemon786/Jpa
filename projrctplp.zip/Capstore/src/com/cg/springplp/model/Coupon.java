package com.cg.springplp.model;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Coupon 
{
	@Id
	
	@NotEmpty(message="This field cannot be empty")
	private String couponCode;
	@NotEmpty(message="This field cannot be empty")
	private String initialDate;
	@NotEmpty(message="This field cannot be empty")
	private String endDate;
	@NotEmpty(message="This field cannot be empty")
	private String discount;
	
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public String getInitialDate() {
		return initialDate;
	}
	public void setInitialDate(String initialDate) {
		this.initialDate = initialDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	
	@Override
	public String toString() {
		return "Coupon [couponCode=" + couponCode + ", initialDate=" + initialDate + ", endDate=" + endDate
				+ ", discount=" + discount + "]";
	}
	
	
	
	
}
