package com.cg.springplp.model;

public enum ModeOfPayment 
{
	CashOnDelivery,
	CreditCard,
	DebitCard;
}
