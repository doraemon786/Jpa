package com.cg.springplp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="customerOrder")
public class CustomerOrder 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Customer customer;

	@OneToOne(cascade=CascadeType.ALL)
	private Coupon coupon;
	@NotBlank(message="This field can't be empty")
	private String orderAddress;
	
	@OneToMany(cascade=CascadeType.ALL)
	private List<Product> product;
	@NotBlank(message="This field can't be empty")
	private double finalPrice;
	@NotNull(message="The field cannot be empty")
	private int quantity;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Merchant merchant;
	@NotBlank(message="This field can't be empty")
	
	private String deliveryStatus;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public String getOrderAddress() {
		return orderAddress;
	}
	public void setOrderAddress(String orderAddress) {
		this.orderAddress = orderAddress;
	}
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	public double getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	
	@Override
	public String toString() {
		return "CustomerOrder [orderId=" + orderId + ", customer=" + customer + ", coupon=" + coupon + ", orderAddress="
				+ orderAddress + ", product=" + product + ", finalPrice=" + finalPrice + ", quantity=" + quantity
				+ ", merchant=" + merchant + ", deliveryStatus=" + deliveryStatus + "]";
	}
	
	
	
}
