package com.cg.springplp.dao;

public interface CustomerDao {

}
