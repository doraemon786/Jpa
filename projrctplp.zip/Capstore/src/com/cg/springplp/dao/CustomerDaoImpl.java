package com.cg.springplp.dao;

public class CustomerDaoImpl 
{

}
