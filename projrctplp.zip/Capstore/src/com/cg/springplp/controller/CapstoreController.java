package com.cg.springplp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CapstoreController 
{
	@RequestMapping("/")
	public String blankPage()
	{
		System.out.println("Hello");
		String view="home";
		return view;
		
	}
}
