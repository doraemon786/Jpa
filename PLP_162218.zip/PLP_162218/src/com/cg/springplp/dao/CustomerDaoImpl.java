package com.cg.springplp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.springplp.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao
{



    @PersistenceContext
	private EntityManager manager;

    
	@Override
	public void insertShippingDetails(Customer cus)
	{
		manager.persist(cus);
	}

}
