package com.cg.springplp.dao;

import com.cg.springplp.model.Customer;

public interface CustomerDao 
{
	void insertShippingDetails(Customer cus);

}
