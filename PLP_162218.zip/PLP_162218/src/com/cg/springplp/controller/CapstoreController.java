package com.cg.springplp.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.springplp.model.Customer;
import com.cg.springplp.service.CustomerService;


@Controller
public class CapstoreController 
{
	
	@Autowired
	CustomerService cusSer;
	


	@RequestMapping("/ShippingInfo")
	public String showRegister(Model model,HttpServletRequest request)
	{

		String view="ShippingDetailsForm";
		model.addAttribute("customer",new Customer());		
		return view;
	}
	
	@RequestMapping(value="/ShippingDetails",method=RequestMethod.POST)
	public String validation(@Valid @ModelAttribute("customer") Customer cus ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
		if(bindingResult.hasErrors())
		{
			view="Register";
			return view;
		}
		else
		{
			cusSer.insertShippingDetails(cus);
			ServletContext context1=req.getServletContext();
			context1.setAttribute("customer",cus);
			view="ShowingShippingDetails";
			return view;
		}
	}


}
