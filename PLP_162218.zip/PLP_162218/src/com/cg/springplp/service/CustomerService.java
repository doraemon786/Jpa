package com.cg.springplp.service;

import com.cg.springplp.model.Customer;

public interface CustomerService 
{
	void insertShippingDetails(Customer cus);

}
