package com.cg.springplp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springplp.dao.CustomerDao;
import com.cg.springplp.model.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService
{

	@Autowired
	CustomerDao cusdao;
	
	@Override
	public void insertShippingDetails(Customer cus) 
	{
		cusdao.insertShippingDetails(cus);
	}	

}
