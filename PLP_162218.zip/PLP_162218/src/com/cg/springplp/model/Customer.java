package com.cg.springplp.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="customer")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="customer_id")
	private int customerId;
	@Column(name="customer_name")
	@NotBlank(message="This field can't be empty")
	private String customerName;
	@Column(name="customer_email")
	@Email
	@NotBlank(message="This field can't be empty")
	private String customerEmail;
	@Column(name="customer_mobile")
	@Digits(integer=10,fraction=0,message="Length should be only 10" )
	@NotBlank(message="This field can't be empty")
	private String customerMobile;
	@Column(name="customer_name")
	@NotBlank(message="This field can't be empty")
	private String customerAddress;
	
		
}
