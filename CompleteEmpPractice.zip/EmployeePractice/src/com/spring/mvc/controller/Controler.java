package com.spring.mvc.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.mvc.exception.meriException;
import com.spring.mvc.model.Employee;
import com.spring.mvc.service.IEmployeeService;

@Controller
public class Controler 
{

	static Employee emps;
	@Autowired
	IEmployeeService empSer;

	@RequestMapping(value="/login")
	public String showLoginPage(Model m)
	{
		String view="login";
		m.addAttribute("employee", new Employee());
		return view;
	}



	@RequestMapping(value="/login1",method=RequestMethod.POST)
	public String validateLogin(Model model, @RequestParam("username")String username, @RequestParam("password")String password)
	{
		String view="";

		if(("admin".equalsIgnoreCase(username)) && ("admin".equalsIgnoreCase(password)))
		{
			view="";
			model.addAttribute("msg","username");
			view="Homepage";
			return view;
		}
		else
		{
			view="";
			model.addAttribute("msg","Login Denied");
			view="error";
			return view;
		}
	}

	@RequestMapping("/Homepage")
	public String showHomePage()
	{
		String view="Homepage";
		return view;
	}

	@RequestMapping("/MyregisterPage")
	public String showRegister(Model model,HttpServletRequest request)
	{

		String view="Register";
		model.addAttribute("msg","Welcome To Registration Page");
		model.addAttribute("employee",new Employee());		
		List<String>list=new ArrayList<>();
		list.add("Ghaziabad");
		list.add("Lucknow");
		list.add("Mumbai");
		list.add("Pune");
		list.add("Chennai");
		ServletContext context=request.getServletContext();
		context.setAttribute("city",list);
		List<String>list1=new ArrayList<>();
		list1.add("male");
		list1.add("female");
		list1.add("transgender");
		ServletContext context2=request.getServletContext();
		context2.setAttribute("numberlist",list1);
		return view;
	}

	@RequestMapping(value="/Registeration",method=RequestMethod.POST)
	public String validation(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
		if(bindingResult.hasErrors())
		{
			view="Register";
			return view;
		}
		else
		{
			empSer.insertEmployee(emp);
			ServletContext context1=req.getServletContext();
			context1.setAttribute("employee",emp);
			view="success";
			return view;
		}
	}

	@RequestMapping(value="/Update")
	public String updaateEmp(Model model,HttpServletRequest request)
	{
		String view="UpdatePage";
		model.addAttribute("employee",new Employee());
		model.addAttribute("msg","Welcome To Updation Page");
		return view;
	}

	@RequestMapping("/Updated")

	public String showRegister1(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req) throws meriException
	{

		String view="";
		emps =empSer.updateEmployee(emp.getEmpId());
		if(emps!=null)
		{

			model.addAttribute("msg","Welcome To Registration Page");
			model.addAttribute("employee",new Employee());		
			List<String>list=new ArrayList<>();
			list.add("Ghaziabad");
			list.add("Lucknow");
			list.add("Mumbai");
			list.add("Pune");
			list.add("Chennai");
			ServletContext context=req.getServletContext();
			context.setAttribute("city",list);
			List<String>list1=new ArrayList<>();
			list1.add("male");
			list1.add("female");
			list1.add("transgender");
			ServletContext context2=req.getServletContext();
			context2.setAttribute("numberlist",list1);
			view="EmployeeData";
			return view;
		}
		else
		{
			throw new meriException("Sorry! ID not found");
		}
	}

	@RequestMapping(value="/lastupdate")
	public String finallyUpdateEmployee(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		empSer.updatedEmployeeDetails(emp, emps);
		String view="UpdateConfirmation";
		model.addAttribute("msg2", "Updated Sucessfully");
		return view;

	}

	@RequestMapping("/Delete")
	public String deleteEmployee(Model model,HttpServletRequest request)
	{
		model.addAttribute("employee", new Employee());
		String view="deleteEmployee";
		model.addAttribute("msg", "Delete Employee Console");
		return view;

	}

	@RequestMapping(value="/Deletekarbhai")
	public String deletedkardeyaar(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req) throws meriException
	{
		empSer.deleteEmpById(emp.getEmpId());

		String view="Deleted";
		model.addAttribute("msg2", "Deleted Sucessfully");
		return view;

	}

	@RequestMapping("/Showall")
	public String showAllData(Model model,HttpServletRequest request) throws meriException
	{
		String view="";
		List<Employee>employeeList1=empSer.getAll();
		if(employeeList1!=null)

		{
			model.addAttribute("employee", employeeList1);
			view="ShowAll";
			return view;
		}
		else
		{
			throw new meriException("No data found");
		}
	}
}
