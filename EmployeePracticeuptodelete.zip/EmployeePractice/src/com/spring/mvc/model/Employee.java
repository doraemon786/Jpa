package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee 
{


	public Employee()
	{
		super();
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int empId;
	@NotEmpty(message="Name Cannot be Empty")
	@Size(max=10,min=3)
String name;
	
String companyName;
@NotEmpty(message="Designation Cannot be Empty")
String designation;
@NotEmpty(message="Salary Cannot be Empty")
String salary;
@NotEmpty(message="City Cannot be Empty")
String  city;
	@NotEmpty(message="Gender Cannot be Empty")
String gender;
String empId1;

	public String getEmpId1() {
	return empId1;
}
public void setEmpId1(String empId1) {
	this.empId1 = empId1;
}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	public Employee(int empId, String name, String companyName, String designation, String salary, String city,
			String gender) {
		super();
		this.empId = empId;
		this.name = name;
		this.companyName = companyName;
		this.designation = designation;
		this.salary = salary;
		this.city = city;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", companyName=" + companyName + ", designation="
				+ designation + ", salary=" + salary + ", city=" + city + ", gender=" + gender + "]";
	}
	
	
}
