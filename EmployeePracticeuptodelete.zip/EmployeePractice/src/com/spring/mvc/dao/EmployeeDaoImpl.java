package com.spring.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.exception.meriException;
import com.spring.mvc.model.Employee;
@Repository
public class EmployeeDaoImpl implements IEmployeeDao 

{
	

    @PersistenceContext
	private EntityManager manager;
	

	@Override
	public void insertEmployee(Employee emp) 
	{
		
		manager.persist(emp);
	}


	@Override
	public Employee updateEmployee(int id) {
		Employee emps=manager.find(Employee.class, id);	
		return emps;
	}


	@Override
	public void updatedEmployeeDetails(Employee emp, Employee emps) 
	{
		emps.setCity(emp.getCity());
		emps.setDesignation(emp.getDesignation());
		emps.setGender(emp.getGender());
		emps.setName(emp.getName());
		emps.setSalary(emp.getSalary());
		manager.merge(emps);
		
	}


	@Override
	public void deleteEmpById(int id) throws meriException 
	{
		Employee emps=manager.find(Employee.class, id);	
		if(emps!=null)
		{
			manager.remove(emps);
		}
		else
		{
			throw new meriException("Id doesnot Exsists, nothing to delete");
		}
	}

}
