package com.cg.mbj.dao;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Query;

import com.cg.mbj.dto.BankDetails;
import com.cg.mbj.dto.CustomerDetails;
import com.cg.mbj.dto.Transactions;
import com.cg.mbj.exception.BankException;
import com.cg.mbj.util.DBUtil;




public class BankDaoImpl implements BankDao {

	@Override
	public int createAccount(CustomerDetails cd,BankDetails bank) throws BankException {
		DBUtil db=new DBUtil();
		return db.createAccount(cd,bank);
		
	}

	@Override
	public BankDetails showBalance(int cusAccNum) throws BankException {
		
		DBUtil db=new DBUtil();
		BankDetails f= db.getCustomerInfo(cusAccNum);
		
		return f;
		
	}

	@Override
	public BankDetails deposit(int cusAccNum, int bal) throws BankException {
		DBUtil db=new DBUtil();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();

		List<BankDetails> li2=db.getAllBankAccount();
		BankDetails bd1=em.find(BankDetails.class,cusAccNum);
		if(bd1!=null)
		{
			bd1.setCusBal(bd1.getCusBal()+bal);
			em.getTransaction().begin();
			em.merge(bd1);
		
			/*DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd:hh:mm:ss");
			LocalDateTime ld=LocalDateTime.now();
			String date=dtf.format(ld);*/
			Transactions trans=new Transactions();
			trans.setAmount(bal);
			trans.setAvailbal(bd1.getCusBal());
			//trans.setDate(date);
			trans.setTranstype("Deposit");
			trans.setAccnum(bd1.getAccNum());
			em.merge(trans);
			em.getTransaction().commit();
			return bd1;
		}
			return null;
		
	}

	@Override
	public BankDetails withdraw(int cusAccNum, int bal) throws BankException {
		DBUtil db1=new DBUtil();
		List<BankDetails> li3=db1.getAllBankAccount();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		BankDetails bd2=em.find(BankDetails.class,cusAccNum);
		if(bd2!=null)
		{
			bd2.setCusBal(bd2.getCusBal()-bal);
			em.getTransaction().begin();
			em.merge(bd2);
			Transactions trans=new Transactions();
			trans.setAmount(bal);
			trans.setAvailbal(bd2.getCusBal());
			trans.setTranstype("Withdraw");
			trans.setAccnum(bd2.getAccNum());
			em.merge(trans);
			em.getTransaction().commit();
			return bd2;
		}
		return null;
	}

	@Override
	public BankDetails fundTransfer(int AccNum,int transferAccNum, int bal) {
		DBUtil db4=new DBUtil();
		List<BankDetails> li4=db4.getAllBankAccount();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		BankDetails bd3=em.find(BankDetails.class,transferAccNum);
		BankDetails bd4=em.find(BankDetails.class,AccNum);
		if(bd3!=null&& bd4!=null)
		{
			bd3.setCusBal(bd3.getCusBal()+bal);
			em.getTransaction().begin();
			em.merge(bd3);
			
			bd4.setCusBal(bd4.getCusBal()-bal);
		
			em.merge(bd4);
			em.getTransaction().commit();
			return bd4;
		}
	
		return null;

	}

	@Override
	public List<Transactions> printTransaction(int AccNum) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		em.getTransaction().begin();
		javax.persistence.Query query=em.createQuery("from Transactions where accnum=?");
		query.setParameter(1, AccNum);
		List<Transactions> transaction=query.getResultList();
		if(transaction!=null)
		{
			return transaction;
		}
	em.getTransaction().commit();
	return null;
	
}


	
}
