package com.cg.mbj.ui;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.mbj.dto.BankDetails;
import com.cg.mbj.dto.CustomerDetails;
import com.cg.mbj.dto.Transactions;
import com.cg.mbj.exception.BankException;
import com.cg.mbj.service.BankService;
import com.cg.mbj.service.BankServiceImpl;

public class CustomerMain {
static Scanner sc=null;
static int choice=0;
static BankService ser=null;
	public static void main(String[] args) throws BankException {

		
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("PAYMENT WALLET APPLICATION");
			System.out.println("Choose an operation");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transaction");
			choice=sc.nextInt();
			performOperation(choice);
			
		}
	}
	private static void performOperation(int choice) throws BankException {
		switch(choice)
		{
		case 1:createAccount();break;
		case 2:showBalance();break;
		case 3:deposit();break;
		case 4:withdraw();break;
		case 5:fundTransfer();break;
		case 6:printTransaction();break;
		default :System.exit(0);
		}
	}
	private static void printTransaction() throws BankException 
	{
		System.out.println("Enter the Account Number to print Transaction Details");
		int accNum=sc.nextInt();
		BankServiceImpl ser5=new BankServiceImpl();
		List<Transactions> t=ser5.printTransaction(accNum);
		for(int i=0;i<t.size();i++)
		{
			Transactions t1=t.get(i);
		System.out.println(t1.getAccnum());
		System.out.println(t1.getAmount());
		System.out.println(t1.getAvailbal());
		System.out.println(t1.getTranstype());
		}
		
		
		
	}
	private static void fundTransfer() {
		System.out.println("Enter the Account Number for transferring money");
		int transferAccNum=sc.nextInt();
		System.out.println("Enter your Account Number");
		int AccNum=sc.nextInt();
		System.out.println("Enter the Amount you want to transfer");
		int transferBal=sc.nextInt();
		BankServiceImpl ser4=new BankServiceImpl();
		BankDetails tranferDetails=ser4.fundTransfer(AccNum, transferAccNum, transferBal);
		
	
		System.out.println("-----------------------------------------");
		System.out.println("Rs."+transferBal+"has been transferred from " +AccNum+" to"+transferAccNum+" and your reamiming balance is "+tranferDetails.getCusBal());
		System.out.println("-----------------------------------------");
	}
	private static void withdraw() throws BankException {
		System.out.println("Enter The Amount you want to withdraw");
		int depBal=sc.nextInt();
		System.out.println("Enter The Account Number");
		int cusAccNo=sc.nextInt();
		BankServiceImpl ser3=new BankServiceImpl();
		
		BankDetails withAmt=ser3.withdraw(cusAccNo, depBal);
		if(withAmt!=null)
		{
			System.out.println("-----------------------------------------");
		System.out.println("Hello "+withAmt.getCusDetails().getCusName()+" Rs."+withAmt.getCusBal()+" for Account Number: "+withAmt.getAccNum());
		System.out.println("-----------------------------------------");
		}
		else
		{
			System.out.println("enter the correct account number");
		}
	}
	private static void deposit() throws BankException {
		System.out.println("Enter The Amount you want to deposit");
		int depBal=sc.nextInt();
		System.out.println("Enter The Account Number");
		int cusAccNo=sc.nextInt();
		BankServiceImpl ser2=new BankServiceImpl();
		BankDetails b=ser2.deposit(cusAccNo, depBal);	
		System.out.println(b.getAccNum()+" "+b.getCusBal());
		
	}
	private static void showBalance() throws BankException {
		System.out.println("Enter your Account Number");
		int findBal=sc.nextInt();
		BankServiceImpl ser1=new BankServiceImpl();
		BankDetails bal=ser1.showBalance(findBal);
		
		System.out.println("-----------------------------------------");
		System.out.println("Hello "+" "+bal.getCusDetails().getCusName()+" Your Balance for "+bal.getAccNum()+" is Rs. "+bal.getCusBal());
		System.out.println("-----------------------------------------");
	}
	private static void createAccount() throws BankException {
		System.out.println("---------welcome----------");
		
		System.out.println("Enter customer name");
		String cusName=sc.next();
		System.out.println("Enter customer age");
		int cusAge=sc.nextInt();
		System.out.println("Enter customer Address");
		String cusAddress=sc.next();
		System.out.println("Enter customer Gender");
		String cusGender=sc.next();
		System.out.println("Enter customer City");
		String cusCity=sc.next();
		CustomerDetails cd=new CustomerDetails(cusName,cusAge,cusAddress,cusGender,cusCity);
	    ser=new BankServiceImpl();
		System.out.println("Enter customer Balance");
		int cusBal=sc.nextInt();
		BankDetails bank=new BankDetails(cusBal,cd);
		 int accNumber=ser.createAccount(cd,bank);
		 System.out.println("-------------------------------------------------");
		 System.out.println("Your account has been succesfully created with Account Number: "+accNumber);
		 System.out.println("-------------------------------------------------");
	
	}

}
