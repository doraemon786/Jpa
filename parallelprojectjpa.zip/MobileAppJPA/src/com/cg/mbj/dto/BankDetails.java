package com.cg.mbj.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ForeignKey;

@Entity
public class BankDetails 
{
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		int accNum;
		int cusBal;
		@ManyToOne
		CustomerDetails cusDetails;

		public BankDetails(int cusBal, CustomerDetails cusDetails) 
		{
				super();
				this.cusBal = cusBal;
				this.cusDetails = cusDetails;
		}
		public BankDetails()
		{
			
		}

		public CustomerDetails getCusDetails() 
		{
			return cusDetails;
		}
		
		public void setCusDetails(CustomerDetails cusDetails) {
			this.cusDetails = cusDetails;
		}
		
		@Override
		public String toString() {
			return "BankDetails [accNum=" + accNum + ", cusBal=" + cusBal
					+ ", cusDetails=" + cusDetails + "]";
		}
		public int getAccNum() {
			return accNum;
		}
		public void setAccNum(int accNum) {
			this.accNum = accNum;
		}
		public int getCusBal() {
			return cusBal;
		}
		public void setCusBal(int cusBal) {
			this.cusBal = cusBal;
		}
		}
