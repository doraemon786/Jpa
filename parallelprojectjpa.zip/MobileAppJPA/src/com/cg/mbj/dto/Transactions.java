package com.cg.mbj.dto;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transactions 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transId;
	private int accnum;
	private String transtype;
	//String date;
	private int amount;
	private int availbal;
	
	public int getAvailbal() {
		return availbal;
	}


	public void setAvailbal(int availbal) {
		this.availbal = availbal;
	}


	public Transactions() {
	
	}


	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	/*public String getDate() {
		return date;
	}*/
	/*public void setDate(String date) {
		this.date = date;
	}*/
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}


	public int getAccnum() {
		return accnum;
	}


	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}



}
