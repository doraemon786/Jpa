package com.cg.mbj.service;

import java.util.List;

import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;

import com.cg.mbj.dao.BankDao;
import com.cg.mbj.dao.BankDaoImpl;
import com.cg.mbj.dto.BankDetails;
import com.cg.mbj.dto.CustomerDetails;
import com.cg.mbj.dto.Transactions;
import com.cg.mbj.exception.BankException;



public class BankServiceImpl implements BankService{

	@Override
	public int createAccount(CustomerDetails cd,BankDetails bank) throws BankException {
		BankDaoImpl bankdao=new BankDaoImpl();
		return bankdao.createAccount(cd,bank);
	}
	@Override
	public BankDetails showBalance(int cusAccNum) throws BankException {
		BankDaoImpl bankdao=new BankDaoImpl();
		
		return bankdao.showBalance(cusAccNum);
	}
	@Override
	public BankDetails deposit(int cusAccNum, int bal) throws BankException 
	{
		BankDaoImpl bankdao=new BankDaoImpl();
		return bankdao.deposit(cusAccNum, bal);
		
	}
	@Override
	public BankDetails withdraw(int cusAccNum, int bal) throws BankException {
		BankDaoImpl bankdao=new BankDaoImpl();
		return bankdao.withdraw(cusAccNum, bal);
	}
	@Override
	public BankDetails fundTransfer(int AccNum,int transferAccNum, int bal) {
		BankDaoImpl bankdao=new BankDaoImpl();
		return bankdao.fundTransfer(AccNum, transferAccNum, bal);
	}
	@Override
	public List<Transactions> printTransaction(int AccNum) {
		BankDaoImpl bankdao=new BankDaoImpl();
		return bankdao.printTransaction(AccNum);
	}

	


}
