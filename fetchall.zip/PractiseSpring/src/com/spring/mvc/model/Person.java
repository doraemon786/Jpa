package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Person 
{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int personid;
	public int getPersonid() {
	return personid;
}
public void setPersonid(int personid) {
	this.personid = personid;
}
	private String personname;
	private String personaddress;
	private String perosnnumber;

	public String getPersonname() {
		return personname;
	}
	public void setPersonname(String personname) {
		this.personname = personname;
	}
	public String getPersonaddress() {
		return personaddress;
	}
	public void setPersonaddress(String personaddress) {
		this.personaddress = personaddress;
	}
	public String getPerosnnumber() {
		return perosnnumber;
	}
	public void setPerosnnumber(String perosnnumber) {
		this.perosnnumber = perosnnumber;
	}
	public Person() {
		super();
	}
	public Person(int personid,String personname, String personaddress, String perosnnumber) {
		super();
		this.personid=personid;
		this.personname = personname;
		this.personaddress = personaddress;
		this.perosnnumber = perosnnumber;
	}
	
	
}
