package com.spring.mvc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.mvc.model.Person;
import com.spring.mvc.service.IService;
@Controller
public class ControllerPage 
{
@Autowired
IService iservice;
	@RequestMapping("/HomePage")
	public String doProcess()
	{
		String view="HomePage";
		return view;
	}
	@RequestMapping(value="/show")
	public String showpage(Model model,HttpServletRequest request)
	{
		String view="";
		List<Person> list=iservice.showalldetails();
		model.addAttribute("msg","Welcome to employee Details page");
		ServletContext context=request.getServletContext();
		context.setAttribute("personlist", list);
		view="showdetailspage";
		return view;
	}
	
}
