package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Person;

public interface IService 
{
	public List<Person> showalldetails();
}
