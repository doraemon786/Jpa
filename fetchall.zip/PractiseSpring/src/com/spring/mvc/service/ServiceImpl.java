package com.spring.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.IDao;
import com.spring.mvc.model.Person;
@Service
@Transactional
public class ServiceImpl implements IService{
	@Autowired
	IDao idao;
	@Override
	public List<Person> showalldetails() {
	return idao.showalldetails();
	}

}
