package com.spring.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Person;
@Repository
public class DaoImpl implements IDao{

	@PersistenceContext
	EntityManager manager;
	@Override
	public List<Person> showalldetails() {
		Query query=manager.createQuery("from Person");
		List<Person> person=query.getResultList();
		return person;
	}

}
