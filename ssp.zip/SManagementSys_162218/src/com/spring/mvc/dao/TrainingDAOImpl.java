package com.spring.mvc.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.ScheduleSession;
@Repository
public class TrainingDAOImpl implements ITrainingDAO
{

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public List<ScheduleSession> fetchall() 
	{

		Query query=manager.createQuery("from schedule");
		List<ScheduleSession>list=new ArrayList<ScheduleSession>();
		list=query.getResultList();
		
		return list;
		
		
		
	}

}
