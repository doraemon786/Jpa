package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.ScheduleSession;

public interface ITrainingService 
{
	List<ScheduleSession>fetchall();

}
