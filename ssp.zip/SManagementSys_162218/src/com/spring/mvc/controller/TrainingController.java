package com.spring.mvc.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.mvc.model.ScheduleSession;
import com.spring.mvc.service.ITrainingService;

@Controller
public class TrainingController 
{
	
	@Autowired
	ITrainingService ITSer;
	

	@RequestMapping(value="/homepage")
	public String showHomepage()
	{
		String view="Homepage";
		return view;
	}
	
	@RequestMapping(value="/fetchall")
	public String fetchall(Model model, HttpServletRequest request)
	{

		List<ScheduleSession>list1=new ArrayList<ScheduleSession>();
		ServletContext context=request.getServletContext();
		context.setAttribute("schedulesession1",list1);
		String view="Schedule";
		return view;		
	}


}
