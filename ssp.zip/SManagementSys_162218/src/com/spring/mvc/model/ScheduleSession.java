package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class ScheduleSession 
{
	public ScheduleSession()
	{
		super();
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private int duration;
	private String faculty;
	private String mode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode1() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public ScheduleSession(int id, String name, int duration, String faculty, String mode) {
		super();
		this.id = id;
		this.name = name;
		this.duration = duration;
		this.faculty = faculty;
		this.mode = mode;
	}
	@Override
	public String toString() {
		return "ScheduleSession [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty
				+ "]";
	}
	

}
