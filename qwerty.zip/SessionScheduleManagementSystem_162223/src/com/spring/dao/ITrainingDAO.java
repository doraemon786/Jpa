package com.spring.dao;

import java.util.List;

import com.spring.model.ScheduleSessions;



public interface ITrainingDAO {

	public List<ScheduleSessions> getAll();
}
