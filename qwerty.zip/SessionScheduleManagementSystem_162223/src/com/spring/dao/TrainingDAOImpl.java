package com.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.spring.model.ScheduleSessions;

@Repository
public class TrainingDAOImpl implements ITrainingDAO{


	@PersistenceContext
	EntityManager manager;
	
	@Override
	public List<ScheduleSessions> getAll() {
		Query query = manager.createQuery("from ScheduleSessions",ScheduleSessions.class);
		List<ScheduleSessions> list = query.getResultList();
		return list;
	}

}
