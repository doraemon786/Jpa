package com.spring.service;

import java.util.List;

import com.spring.model.ScheduleSessions;

public interface ITrainingService {

	public List<ScheduleSessions> getAll();
}
