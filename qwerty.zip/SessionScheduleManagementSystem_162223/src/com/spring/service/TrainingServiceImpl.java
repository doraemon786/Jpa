package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.ITrainingDAO;
import com.spring.model.ScheduleSessions;

@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService 
{
	@Autowired
	ITrainingDAO dao;

	@Override
	public List<ScheduleSessions> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}

}
