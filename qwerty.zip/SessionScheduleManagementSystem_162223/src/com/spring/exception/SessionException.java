package com.spring.exception;

public class SessionException extends Exception {


	public SessionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
