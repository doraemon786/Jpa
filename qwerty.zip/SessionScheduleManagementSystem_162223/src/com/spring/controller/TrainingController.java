package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.exception.SessionException;
import com.spring.model.ScheduleSessions;
import com.spring.service.ITrainingService;

@Controller
public class TrainingController {

	@Autowired
	ITrainingService service;
	
	@RequestMapping("/home.do")
	public String showHome()
	{
		String view="HomePage";
		return view;
	}
	
	@RequestMapping("show.do")
	public String showSessions(Model model) throws SessionException
	{
		String view="";
		List<ScheduleSessions> list=service.getAll();
		if(list!=null)
		{
			model.addAttribute("listSess",list);
			view="ScheduledSessions";
		}
		else
		{
			throw new SessionException("Details are incorrect");
		}
		return view;
	}
	
	@RequestMapping("EnrollMe")
	public String showSuccess() 
	{
		String view="SuccessPage";
		return view;
	}
	
	
}
