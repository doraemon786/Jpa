package com.cg.mbj.util;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.mbj.dto.BankDetails;
import com.cg.mbj.dto.CustomerDetails;



public class DBUtil {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=fac.createEntityManager();
	public int createAccount(CustomerDetails cd,BankDetails bank) {
	
		em.getTransaction().begin();
		em.persist(cd);
		em.persist(bank);
		em.getTransaction().commit();
		em.close();
		fac.close();
		return bank.getAccNum();
	} 

	public BankDetails getCustomerInfo(int cusnum)
	{
		em.getTransaction().begin();
			BankDetails bd=em.find(BankDetails.class,cusnum);
			em.getTransaction().commit();
		
			return bd;
		
		
	}



	public static List<BankDetails> getAllBankAccount() {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		em.getTransaction().begin();
		Query ry=em.createQuery("from BankDetails");
		List<BankDetails> li=ry.getResultList();
		em.getTransaction().commit();
		return li;
	}

}


