package com.spring.cust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.cust.exception.CustomerException;
import com.spring.cust.model.Customer;
import com.spring.cust.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService service;
	
	@RequestMapping("/")
	public String showIndex(Model model)
	{
		return "Home";
	}
	
	@RequestMapping(value="/show")
	public String processShow(Model model) throws CustomerException 
	{
		String view="";
		List<Customer> list = service.getAll();
	  if(list !=null)
	  {
		  model.addAttribute("listCus", list);
		  view="display";
		  
	  }else
	  {
		  throw new CustomerException("display is not correct");
		  
	  }
	   return view;
	  
	}
	
	
	
	@RequestMapping(value="/insert")
	public String insertPage(Model model) throws CustomerException 
	{
		model.addAttribute("customer", new Customer());
		return "insertPage";
	  
	}


	@RequestMapping(value="/add")
	public String showAll(@ModelAttribute("customer")Customer cus,Model model) throws CustomerException 
	{
		service.insertTable(cus);
		return "Home";
	}
	

}
