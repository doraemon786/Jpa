package com.spring.cust.service;

import java.util.List;

import com.spring.cust.model.Customer;


public interface ICustomerService {

	public List<Customer> getAll();
	public void insertTable(Customer cus);
}
