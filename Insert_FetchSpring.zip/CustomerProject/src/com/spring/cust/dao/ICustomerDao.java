package com.spring.cust.dao;

import java.util.List;

import com.spring.cust.model.Customer;



public interface ICustomerDao {

	public List<Customer> getAll();
	public void insertTable(Customer cus);
}
