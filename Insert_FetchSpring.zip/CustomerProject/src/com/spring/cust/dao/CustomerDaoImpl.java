package com.spring.cust.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.cust.model.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao{

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public List<Customer> getAll() {
		Query query = manager.createQuery("select cus from Customer cus");
		List<Customer> list = query.getResultList();
		return list;
	}

	@Override
	public void insertTable(Customer cus) {
		manager.persist(cus);
		
	}

}
